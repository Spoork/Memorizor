package com.example.boss.leitnersystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

public class CardPickActivity extends AppCompatActivity {
    private RadioGroup rd1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_pick);
        rd1 = findViewById(R.id.rd1);
    }
    public void RadioButtonClicked(View view){
        switch(rd1.getCheckedRadioButtonId()){

            case R.id.radioButt1 : Toast.makeText(getApplicationContext(),"wrong answer",
                    Toast.LENGTH_SHORT).show();
                break;

            case R.id.radioButt2: Toast.makeText(getApplicationContext(),"wrong answer",
                    Toast.LENGTH_SHORT).show();;
                break;

            case R.id.radioButt3:Toast.makeText(getApplicationContext(),"correct answer",
                    Toast.LENGTH_SHORT).show();
                break;

        }

    }
}
