package com.example.boss.leitnersystem;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CardQuestion extends AppCompatActivity {

    private TextView mQuestionTextView;
    private final static String KEY_INDEX = "index";
    private int currentIndex = 0;
    private Button trueButton, falseButton;
    private Question[] mQuestionBank = new Question[] {
            new Question(R.string.question_australia, true),
            new Question(R.string.question_africa,false),
            new Question(R.string.question_americas,true),
            new Question(R.string.question_oceans,true),
            new Question(R.string.question_mideast,false)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        trueButton = findViewById(R.id.TrueButton);
        falseButton = findViewById(R.id.FalseButton);

        if (savedInstanceState != null)
            currentIndex = savedInstanceState.getInt(KEY_INDEX, 0);

        //question
        mQuestionTextView =  findViewById(R.id.Question);
        int question = mQuestionBank[currentIndex].getQid();
        mQuestionTextView.setText(question);
    }

    public void answerTrue(View view) {

        Boolean chosenAnswer = true;

        if(mQuestionBank[currentIndex].isAns() == chosenAnswer)
            Toast.makeText(this, "CORRECT ANSWER", Toast.LENGTH_SHORT).show();
        else Toast.makeText(this, "INCORRECT ANSWER", Toast.LENGTH_SHORT).show();
    }

    public void answerFalse(View view) {
        Boolean chosenAnswer = false;
        if(mQuestionBank[currentIndex].isAns()==chosenAnswer)
            Toast.makeText(this, "CORRECT ANSWER", Toast.LENGTH_SHORT).show();
        else Toast.makeText(this, "INCORRECT ANSWER", Toast.LENGTH_SHORT).show();

    }


    public void cheatClick(View view) {
        boolean ans = mQuestionBank[currentIndex].isAns();
        if (ans)
            trueButton.setBackground(Color.GREEN);
            else
            falseButton.setBackground(Color.GREEN);

    }
}