package com.example.boss.leitnersystem;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CardQuestion extends AppCompatActivity {

    private TextView mQuestionTextView;
    private final static String KEY_INDEX = "index";
    private int currentIndex = 0;
    private int correctCounter = 0;

    private Button trueButton, falseButton;
    private  Question[] mQuestionBank;

    private String subject = "";
    //history bank
    private Question[] HisQuestionBank = new Question[]{

            new Question(R.string.question_ww2, false, "His"),
            new Question(R.string.question_ww1, true, "His"),
            new Question(R.string.question_france, true, "His")

    };

    //biology bank
    private Question[] BioQuestionBank = new Question[] {

            new Question(R.string.question_Bio1, false, "Bio"),
            new Question(R.string.question_Bio2,false,"Bio"),
            new Question(R.string.question_Bio3,true,"Bio")


    };

    //techno bank
    private Question[] TechnoQuestionBank = new Question[] {

            new Question(R.string.question_IT1, false, "Tech"),
            new Question(R.string.question_IT2,true,"Tech"),
            new Question(R.string.question_IT3,true,"Tech")


    };

    //geography bank
    private Question[] GeoQuestionBank = new Question[] {

            new Question(R.string.question_americas, true, "Geo"),
            new Question(R.string.question_africa,true,"Geo"),
            new Question(R.string.question_asia,false,"Geo")


    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_question);

        trueButton = findViewById(R.id.TrueButton);
        falseButton = findViewById(R.id.FalseButton);

        if (savedInstanceState != null)
            currentIndex = savedInstanceState.getInt(KEY_INDEX, 0);

        //question
        mQuestionTextView = findViewById(R.id.Question);

        Bundle b = getIntent().getExtras();
        String value = b.getString(Intent.EXTRA_TEXT);

        //history questions
        if (value.equals("His")) {

            mQuestionBank = HisQuestionBank;
            int question = mQuestionBank[currentIndex].getQid();
            mQuestionTextView.setText(question);
            subject = value;
        }
        //biology questions
        else if (value.equals("Bio")) {

            mQuestionBank = BioQuestionBank;
            int question = mQuestionBank[currentIndex].getQid();
            mQuestionTextView.setText(question);
            subject = value;
        }
        //technology questions
        else if (value.equals("Tech")) {

            mQuestionBank = TechnoQuestionBank;
            int question = mQuestionBank[currentIndex].getQid();
            mQuestionTextView.setText(question);
            subject = value;
        }
        //geography questions
        else if (value.equals("Geo")) {

            mQuestionBank = GeoQuestionBank;
            int question = mQuestionBank[currentIndex].getQid();
            mQuestionTextView.setText(question);
            subject = value;
        }
    }




    //true button pressed
    public void answerTrue(View view) {

        Boolean chosenAnswer = true;
        if(mQuestionBank[currentIndex].isAns() == chosenAnswer){
            Toast.makeText(this, "CORRECT ANSWER", Toast.LENGTH_SHORT).show();
            correctCounter++;}
        else Toast.makeText(this, "INCORRECT ANSWER", Toast.LENGTH_SHORT).show();

        if(currentIndex == 2){
            check(currentIndex);
        }
        currentIndex++;
        mQuestionTextView.setText(mQuestionBank[currentIndex].getQid());
    }

    //false button pressed
    public void answerFalse(View view) {

        Boolean chosenAnswer = false;
        if(mQuestionBank[currentIndex].isAns()==chosenAnswer){
            Toast.makeText(this, "CORRECT ANSWER", Toast.LENGTH_SHORT).show();
            correctCounter++;}
        else Toast.makeText(this, "INCORRECT ANSWER", Toast.LENGTH_SHORT).show();

        if(currentIndex == 2){
            check(currentIndex);
        }
        currentIndex++;
        mQuestionTextView.setText(mQuestionBank[currentIndex].getQid());

    }

    //update question

    void check(int counter) {
        Intent intent = new Intent(CardQuestion.this, CardPickActivity.class);

        switch (subject){
            case "His":
                intent.putExtra(Intent.EXTRA_TEXT,"His");
                break;
            case "Bio":
                intent.putExtra(Intent.EXTRA_TEXT,"Bio");
                break;
            case "Tech":
                intent.putExtra(Intent.EXTRA_TEXT,"Tech");
                break;
            case "Geo":
                intent.putExtra(Intent.EXTRA_TEXT,"Geo");
                break;
//            case "His":
//            case "His":
        }
        if (counter == 2 && correctCounter == 3) {

            Toast.makeText(this, "WELL DONE", Toast.LENGTH_SHORT).show();
            currentIndex = 0;
            correctCounter = 0;

            setResult(Activity.RESULT_OK, intent);
            finish();

        }
            else if (counter == 2 && correctCounter < 3){

                    Toast.makeText(this, "TRY AGAIN LATER", Toast.LENGTH_SHORT).show();
                    currentIndex = 0;
                    correctCounter = 0;

                    setResult(Activity.RESULT_CANCELED, intent);
                    finish();
            }
    }

}
