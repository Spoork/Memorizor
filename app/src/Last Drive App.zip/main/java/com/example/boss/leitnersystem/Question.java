package com.example.boss.leitnersystem;


public class Question {
    private int qid;
    private boolean ans;
    private String catgeory;

    public Question(int qid, boolean ans, String catgeory) {
        this.qid = qid;
        this.ans = ans;
        this.catgeory = catgeory;
    }



    public String getCatgeory() {
        return catgeory;
    }

    public void setCatgeory(String catgeory) {
        this.catgeory = catgeory;
    }

    public int getQid() {
        return qid;
    }

    public void setQid(int qid) {
        this.qid = qid;
    }

    public boolean isAns() {
        return ans;
    }

    public void setAnswer(boolean ans) {
        this.ans = ans;
    }


}