package com.example.boss.leitnersystem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class CardPickActivity extends AppCompatActivity {

    //cardviews
    private CardView historyCard;
    private CardView biologyCard;
    private CardView technologyCard;
    private CardView geographyCard;
    private CardView sociologyCard;
    private CardView astronomyCard;

//    timers
//    private TextView historyTimer;
//    private TextView biologyTimer;
//    private TextView technoTimer;
//    private TextView geographyTimer;
//    private TextView sociologyTimer;
//    private TextView astronomyTimer;

//    progress bars
   private ProgressBar hisBar;
   private ProgressBar bioBar;
   private ProgressBar techBar;
   private ProgressBar geoBar;
   private ProgressBar socBar;
   private ProgressBar astroBar;


    //card score
    private int  hisScore = 0;
    private int  bioScore= 0;
    private int  techScore= 0;
    private int  geoScore= 0;
    private int  socScore= 0;
    private int  astroScore= 0;

    SharedPreferences pref;
    SharedPreferences.Editor editor;

    //string from question activity
    private String subject = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_pick);

        pref = getApplicationContext().getSharedPreferences("MyPref", Context.MODE_PRIVATE); // 0 - for private mode
        editor = pref.edit();

        //cards
        historyCard = (CardView) findViewById(R.id.historyCard);
        biologyCard = (CardView) findViewById(R.id.biologyCard);
        technologyCard = (CardView) findViewById(R.id.techCard);
        geographyCard = (CardView) findViewById(R.id.geoCard);
        sociologyCard = (CardView) findViewById(R.id.socCard);
        astronomyCard = (CardView) findViewById(R.id.astroCard);

        // progress bars
        hisBar=(ProgressBar)findViewById(R.id.HisPB);
        bioBar=(ProgressBar)findViewById(R.id.BioPB);
        techBar=(ProgressBar)findViewById(R.id.TechPB);
        socBar=(ProgressBar)findViewById(R.id.SocPB);
        astroBar=(ProgressBar)findViewById(R.id.AstPB);
        geoBar=(ProgressBar)findViewById(R.id.GeoPB);

        //session dates
//        historyTimer   = (TextView) findViewById(R.id.historyTimer);
//        biologyTimer   = findViewById(R.id.biologyCard);
//        technoTimer    = findViewById(R.id.technoTimer);
//        geographyTimer = findViewById(R.id.geoTimer);
//        sociologyTimer = findViewById(R.id.socTimer);
//        astronomyTimer = findViewById(R.id.astroTimer);


        //card listeners
        //history card
        historyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
             Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
             intent.putExtra(Intent.EXTRA_TEXT,"His");
             startActivityForResult(intent, 1);

          }
        });

        //biology card
        biologyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
                intent.putExtra(Intent.EXTRA_TEXT,"Bio");
                startActivityForResult(intent, 1);
                if(bioScore==20){


                }
            }
        });

        //technology card
        technologyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
                intent.putExtra(Intent.EXTRA_TEXT,"Tech");
                startActivityForResult(intent, 1);
            }
        });

        //geography card
        geographyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
                intent.putExtra(Intent.EXTRA_TEXT,"Geo");
                startActivityForResult(intent, 1);
            }
        });

        //sociology card
        sociologyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
                intent.putExtra(Intent.EXTRA_TEXT,"Soc");
                startActivityForResult(intent, 1);
            }
        });

        //astronomy card
        astronomyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
                intent.putExtra(Intent.EXTRA_TEXT,"Astro");
                startActivityForResult(intent, 1);
            }
        });


    }

    protected void onPause(){
        super.onPause();
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("History Score", hisScore);
        editor.putInt("Biology Score", bioScore);
        editor.putInt("Technology Score", techScore);
        editor.putInt("Geology Score", geoScore);
        editor.commit();

    }


    public void onResume(){
        super.onResume();

        hisScore = pref.getInt("History Score", 0);
        bioScore = pref.getInt("Biology Score", 0);
        techScore= pref.getInt("Technology Score", 0);
        geoScore = pref.getInt("Geology Score", 0);

        hisBar.setMax(20);
        bioBar.setMax(20);
        techBar.setMax(20);
        geoBar.setMax(20);


        hisBar.setProgress(hisScore);
        bioBar.setProgress(bioScore);
        techBar.setProgress(techScore);
        geoBar.setProgress(geoScore);


    }


    //on activity result
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bundle b = data.getExtras();
        String s = b.getString(Intent.EXTRA_TEXT);


        if (requestCode == 1) {

            if(resultCode == Activity.RESULT_OK){
                switch (s) {
                    case "His":{
                        hisScore+=5;
                        hisBar.setMax(20);
                        hisBar.setProgress(hisScore);
                        if(hisScore==20){
                            historyCard.setClickable(false);
                            Toast toast=Toast.makeText(getApplicationContext(),"You memorized all the history questions good job keep it up",Toast.LENGTH_SHORT);
                            toast.show();
                        }

                        }
                    break;
                    case "Bio":
                        bioScore+=5;
                        bioBar.setMax(20);
                        bioBar.setProgress(bioScore);
                        if(bioScore==20){
                            biologyCard.setClickable(false);
                            Toast toast=Toast.makeText(getApplicationContext(),"You memorized all the biology questions good job keep it up",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        break;
                    case "Tech":
                        techScore+=5;
                        techBar.setMax(20);
                        techBar.setProgress(techScore);
                        if(techScore==20){
                            technologyCard.setClickable(false);
                            Toast toast=Toast.makeText(getApplicationContext(),"You memorized all the technology questions good job keep it up",Toast.LENGTH_SHORT);
                            toast.show();
                        }

                        break;
                    case "Geo":
                        geoScore+=5;
                        geoBar.setMax(20);
                        geoBar.setProgress(geoScore);
                        if(geoScore==20){
                            geographyCard.setClickable(false);
                            Toast toast=Toast.makeText(getApplicationContext(),"You memorized all the geography questions good job keep it up",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        break;
//            case "Soc":
//            case "Astro":
                }
                Toast toast = Toast.makeText(getApplicationContext(),"Try again after 2 days!",Toast.LENGTH_SHORT);
                toast.show();

            }

            if (resultCode == Activity.RESULT_CANCELED) {
                Toast toast = Toast.makeText(getApplicationContext(),"Try again next time!",Toast.LENGTH_SHORT);
                toast.show();
            }
        }
    }
//    date function
//    public Date dateFun (int level){
//        Calendar c = Calendar.getInstance();
//        Date today = c.getTime();
//
//        c.add(Calendar.DATE, level);
//        c.add(Calendar.MONTH, 0);
//        c.add(Calendar.YEAR, 0);
//        Date nextSession = c.getTime();
//        return nextSession;
//    }
}
