package com.example.boss.leitnersystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

public class CardPickActivity extends AppCompatActivity {

    private CardView historyCard;
    private CardView biologyCard;
    private CardView technologyCard;
    private CardView geographyCard;
    private CardView sociologyCard;
    private CardView astronomyCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_pick);

        historyCard =  findViewById(R.id.historyCard);
        biologyCard =  findViewById(R.id.biologyCard);
        technologyCard = findViewById(R.id.techCard);
        geographyCard = findViewById(R.id.geoCard);
        sociologyCard = findViewById(R.id.socCard);
        astronomyCard = findViewById(R.id.astroCard);

        historyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
             Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
             intent.putExtra("history",true);
             startActivity(intent);
          }
        });

        biologyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
                intent.putExtra("bio",true);
                startActivity(intent);
            }
        });

        technologyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
            intent.putExtra("techno",true);
            startActivity(intent);
        }
    });
        geographyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
            intent.putExtra("geo",true);
            startActivity(intent);
        }
    });

        sociologyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
            intent.putExtra("astro",true);
            startActivity(intent);
        }
    });

        astronomyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
            startActivity(intent);
        }
    });
}}
