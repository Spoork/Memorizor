package com.example.boss.leitnersystem;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class CardPickActivity extends AppCompatActivity {

    //cardviews
    private CardView historyCard;
    private CardView biologyCard;
    private CardView technologyCard;
    private CardView geographyCard;
    private CardView sociologyCard;
    private CardView astronomyCard;

    //timers
    private TextView historyTimer;
    private TextView biologyTimer;
    private TextView technoTimer;
    private TextView geographyTimer;
    private TextView sociologyTimer;
    private TextView astronomyTimer;

    //progress bar
    private ProgressBar hisBar;
    private ProgressBar bioBar;
    private ProgressBar techBar;
    private ProgressBar geoBar;
    private ProgressBar socBar;
    private ProgressBar astroBar;

    private int mProgressStatus = 0;
    
    //session increase
    private static final int level1 = 2;
    private static final int level2 = 4;
    private static final int level3 = 7;

    Intent intent = new Intent(CardPickActivity.this, CardQuestion.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_pick);

        //cards
        historyCard =  findViewById(R.id.historyCard);
        biologyCard =  findViewById(R.id.biologyCard);
        technologyCard = findViewById(R.id.techCard);
        geographyCard = findViewById(R.id.geoCard);
        sociologyCard = findViewById(R.id.socCard);
        astronomyCard = findViewById(R.id.astroCard);

        //session dates
        historyTimer   = findViewById(R.id.historyTimer);
        biologyTimer   = findViewById(R.id.biologyCard);
        technoTimer    = findViewById(R.id.technoTimer);
        geographyTimer = findViewById(R.id.geoTimer);
        sociologyTimer = findViewById(R.id.socTimer);
        astronomyTimer = findViewById(R.id.astroTimer);

        //card listeners
        //history card
        historyCard.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
             intent.putExtra("history",true);
             startActivity(intent);
          }
        });

        //biology card
        biologyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("bio",true);
                startActivity(intent);
            }
        });

        //technology card
        technologyCard.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                intent.putExtra("techno",true);
                startActivity(intent);
            }
        });

        //geography card
        geographyCard.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                intent.putExtra("geo",true);
                startActivity(intent);
             }
        });

        //sociology card
        sociologyCard.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  intent.putExtra("Soc",true);
                  startActivity(intent);
              }
        });

        //astronomy card
        astronomyCard.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                    intent.putExtra("astro",true);
                    startActivity(intent);
               }
        });
    }

    //on activity result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
                boolean cheatTest = data.getBooleanExtra("Cheater",false);

            }
            if (resultCode == Activity.RESULT_CANCELED) {
                Toast toast = Toast.makeText(getApplicationContext(),"Try again next time!",Toast.LENGTH_SHORT);
                toast.show();
            }
        }
    }
    //date function
    public Date dateFun (int level){
        Calendar c = Calendar.getInstance();
        Date today = c.getTime();

        c.add(Calendar.DATE, level);
        c.add(Calendar.MONTH, 0);
        c.add(Calendar.YEAR, 0);
        Date nextSession = c.getTime();
        return nextSession;
    }
}
