package com.example.boss.leitnersystem;


public class Question {
    private int qid;
    private boolean ans;

    public Question(int id, boolean a){
        qid = id;
        ans = a;
    }

    public int getQid() {
        return qid;
    }

    public void setQid(int qid) {
        this.qid = qid;
    }

    public boolean isAns() {
        return ans;
    }

    public void setAnswer(boolean ans) {
        this.ans = ans;
    }
}