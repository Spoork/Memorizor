package com.example.boss.leitnersystem;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CardQuestion extends AppCompatActivity {

    private TextView mQuestionTextView;
    private final static String KEY_INDEX = "index";
    private int currentIndex = 0;
    private int questionCounter = 0;

    private Button trueButton, falseButton;
    private Question[] mQuestionBank = new Question[] {
            new Question(R.string.question_ww2, false),
            new Question(R.string.question_ww1,true),
            new Question(R.string.question_france,true)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_question);

        trueButton = findViewById(R.id.TrueButton);
        falseButton = findViewById(R.id.FalseButton);

        if (savedInstanceState != null)
            currentIndex = savedInstanceState.getInt(KEY_INDEX, 0);

        //question
        mQuestionTextView =  findViewById(R.id.Question);
        int question = mQuestionBank[currentIndex].getQid();
        mQuestionTextView.setText(question);
    }

    public void answerTrue(View view) {

        Boolean chosenAnswer = true;

        if(mQuestionBank[currentIndex].isAns() == chosenAnswer)
            Toast.makeText(this, "CORRECT ANSWER", Toast.LENGTH_SHORT).show();
        else Toast.makeText(this, "INCORRECT ANSWER", Toast.LENGTH_SHORT).show();
    }

    public void answerFalse(View view) {
        Boolean chosenAnswer = false;
        if(mQuestionBank[currentIndex].isAns()==chosenAnswer){
            questionCounter++;
            Toast.makeText(this, "CORRECT ANSWER", Toast.LENGTH_SHORT).show();}
        else Toast.makeText(this, "INCORRECT ANSWER", Toast.LENGTH_SHORT).show();

    }

    //update question
    public void updateQuestion(View view){
        currentIndex++;

        if(currentIndex == mQuestionBank.length){
            if(questionCounter == 3)
                {
                    Toast.makeText(this, "Well Done!", Toast.LENGTH_SHORT).show();
                    currentIndex=0;
                    Intent completed = new Intent();
                    completed.putExtra("completed",true);
                    setResult(Activity.RESULT_OK,completed);
                }
            else
                {
                    Toast.makeText(this, "TRY AGAIN LATER", Toast.LENGTH_SHORT).show();currentIndex=0;
                    Intent incomplete = new Intent();
                    incomplete.putExtra("incomplete",true);
                    setResult(Activity.RESULT_CANCELED,incomplete);
                }
        }
        else
        mQuestionTextView.setText(mQuestionBank[currentIndex].getQid());
    }

    public void cheatClick(View view) {
        boolean ans = mQuestionBank[currentIndex].isAns();
        if (ans)
            trueButton.setBackgroundColor(Color.MAGENTA);
            else
            falseButton.setBackgroundColor(Color.MAGENTA);

    }
}